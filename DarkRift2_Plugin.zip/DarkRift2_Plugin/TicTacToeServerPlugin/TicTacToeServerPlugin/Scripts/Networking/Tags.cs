﻿
namespace Scripts.Networking {
	class Tags {

		public enum Tag {
			SET_NAME,
			GOT_MATCH,
			SLATE_TAKEN,
			SERVER_CONFIRM_SLATE_TAKEN
		}

	}
}
